﻿using System.Windows.Forms;

namespace WoWPlugin_Test
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            TopMost = true;
        }
    }
}
