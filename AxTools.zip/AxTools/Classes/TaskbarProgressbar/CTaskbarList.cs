﻿using System.Runtime.InteropServices;

namespace AxTools.Classes.TaskbarProgressbar
{
    [Guid("56FDF344-FD6D-11d0-958A-006097C9A090")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    internal class CTaskbarList { }
}