﻿using System.Diagnostics;
using AxTools.Forms;
using GreyMagic;

namespace AxTools.Classes.WoW.Management
{
    internal static class WoWManager
    {

        internal static WowProcess WowProcess;
        internal static bool Hooked { private set; get; }

        internal static HookResult Hook(WowProcess process)
        {
            WowProcess = process;
            if (WowProcess.Memory == null)
            {
                WowProcess.Memory = new ExternalProcessReader(Process.GetProcessById(WowProcess.ProcessID));
            }
            if (!WoWDXInject.Apply(WowProcess))
            {
                return HookResult.IncorrectDirectXVersion;
            }
            ObjectMgr.Initialize(WowProcess);
            Hooked = true;
            return HookResult.Successful;
        }

        internal static void Unhook()
        {
            WowRadarOptions pWowRadarOptions = Utils.FindForm<WowRadarOptions>();
            if (pWowRadarOptions != null) pWowRadarOptions.Close();
            WowRadar pWowRadar = Utils.FindForm<WowRadar>();
            if (pWowRadar != null) pWowRadar.Close();
            LuaConsole pLuaInjector = Utils.FindForm<LuaConsole>();
            if (pLuaInjector != null) pLuaInjector.Close();

            WoWDXInject.Release();
            Log.Print(string.Format("{0}:{1} :: [WoW hook] Total objects cached: {2}", WowProcess.ProcessName, WowProcess.ProcessID, WowObject.Names.Count), false, false);
            WowObject.Names.Clear();
            Log.Print(string.Format("{0}:{1} :: [WoW hook] Total players cached: {2}", WowProcess.ProcessName, WowProcess.ProcessID, WowPlayer.Names.Count), false, false);
            WowPlayer.Names.Clear();
            Log.Print(string.Format("{0}:{1} :: [WoW hook] Total NPC cached: {2}", WowProcess.ProcessName, WowProcess.ProcessID, WowNpc.Names.Count));
            WowNpc.Names.Clear();
            Hooked = false;
        }

    }
}
