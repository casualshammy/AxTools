﻿namespace AxTools.Classes.WoW
{
    internal enum WowPlayerClass : byte
    {
        War = 1,
        Pal = 2,
        Hun = 3,
        Rog = 4,
        Pri = 5,
        DK = 6,
        Sha = 7,
        Mg = 8,
        WL = 9,
        Mnk = 10,
        Dru = 11,
    }
}