﻿namespace AxTools.Classes.WoW
{
    internal enum HookResult
    {
        None = 0x0,
        Successful = 0x1,
        IncorrectDirectXVersion = 0x2,
    }
}